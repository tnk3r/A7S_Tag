	                                 _                             _   _____
   	        _ __ ___ _ __ ___   ___ | |_ ___         ___ _   _ ___| |_|___ /_ __ ___
       	   | '__/ _ \ '_ ` _ \ / _ \| __/ _ \      / __| | | / __| __| |_ \| '_ ` _ \
     	   | | |  __/ | | | | | (_) | ||  __/   _  \__ \ |_| \__ \ |_ ___) | | | | | |
       	   |_|  \___|_| |_| |_|\___/ \__\___|  (_) |___/\__, |___/\__|____/|_| |_| |_|
                                                           |___/

            // Sony XAVC Folder Stucture Re-tagger / RENAME SCRIPT //
            MAC OSX ONLY WITH CocoaDialog.app && Finder Pop

            THIS SCRIPT ASSUMES THE NORMAL DIRECTORY STRUCTURE OF A7S & OTHER SONY XAVC FILES
            IF YOU HAVE ALREADY RENAMED YOUR MEDIA I DO NOT SUGGEST RUNNING THIS SCRIPT
            TRY IT OUT TO SEE IF IT FITS IN YOUR WORKFLOW
            FOLDERS WORK WELL, DEPENDING ON YOUR DIRECTORY STRUCTURE LAYOUT
            PLEASE TRY NOT TO USE SPACES, THEY WILL WORK. BUT HIGHLY DISCOURAGED
            KEEP IN MIND ANY FILE NAMES WITH SPACES IN THEM ARE NOT PROFESSIONAL

            Use the MP_ROOT as your target folder or the Folder Directly Before the MP4 Files.

            This script will not re-order clip name to clip 001.
            It will use the provided Sony Clip Number given to the clips already.

            INSTALLATION:

            copy the files inside the supplied .Zip into your /Applications Folder
            Then you can double click on the go-rename file to open the Dialog
            You must install the supplied Cocoa DIALOG .app (DO NOT TRY TO RUN IT DIRECTLY)
            YOU CAN EMAIL ME AT remote.syst3m@gmail.com FOR QUESTIONS or create an issue on github.com/tnk3r (better)

            A really smooth way of using this tool is with FinderPop.
            You can simply drop this script into ~/Library/FinderPop Items/
            Now the script will be selectable on your right-click,
            If you right-click on the MP_ROOT Directory.
            Then that Folder will be used instead of opening a dialog and selecting the folder

            USE AT YOUR OWN RISK
            YOU HAVE BEEN WARNED

